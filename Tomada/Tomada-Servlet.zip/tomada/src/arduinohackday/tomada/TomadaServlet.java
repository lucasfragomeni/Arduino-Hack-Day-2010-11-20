package arduinohackday.tomada;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.globalcode.eletronlivre.arduino.serial.Arduino;

@SuppressWarnings("serial")
public class TomadaServlet extends HttpServlet {

	@Override
	public void init() throws ServletException {
		Arduino.init("/dev/tty.usbserial-A600dT8w");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
    
		String estado = req.getParameter("estado");
		if(estado == null) estado = "1";

		try {
			Arduino.enviar(new byte[] {Byte.parseByte(estado)});
			Arduino.delay(100);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		if(estado.equals("1")) estado = "0";
		else estado = "1";

		resp.getWriter().write("<html><body><table width='100%' height='100%'>");
		resp.getWriter().write("<tr width='100%' height='100%' valign='middle' align='center'><td width='100%' height='100%'>");
		resp.getWriter().write("<form><input type='hidden' name='estado' value='" + estado + "'/>");
		resp.getWriter().write("<input type='submit' value='" + (estado.equals("1") ? "Ligar" : "Desligar") + "'/></form>");
		resp.getWriter().write("</td></tr></table></body></html>");
	}
}